<?php

$str = "a b";
$data = explode(" ", $str);
echo ($data);


?>